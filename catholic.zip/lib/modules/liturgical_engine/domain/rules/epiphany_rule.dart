import '../value_objects/calendar_context.dart';
import 'celebration_rule.dart';

class EpiphanyRule implements CelebrationRule {
  const EpiphanyRule();

  @override
  DateTime resolve(CalendarContext context) {
    // Traditional Roman Calendar
    if (!context.settings.transferEpiphany) {
      return DateTime(context.year, 1, 6);
    }

    // Transfer to the Sunday between Jan 2–8
    for (int day = 2; day <= 8; day++) {
      final date = DateTime(context.year, 1, day);

      if (date.weekday == DateTime.sunday) {
        return date;
      }
    }

    throw StateError('Unable to calculate Epiphany.');
  }
}