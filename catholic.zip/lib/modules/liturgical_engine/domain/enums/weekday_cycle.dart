enum WeekdayCycle {
  i,
  ii,
}