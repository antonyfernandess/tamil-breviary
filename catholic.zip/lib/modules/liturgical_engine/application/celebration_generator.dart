import 'package:catholic/modules/liturgical_engine/application/services/liturgical_precedence.dart';
import '../domain/definitions/celebration_definition.dart';
import '../domain/definitions/liturgical_calendar.dart';
import '../domain/entities/celebration.dart';
import '../domain/value_objects/calendar_context.dart';
import '../domain/value_objects/calendar_settings.dart';

/// Generates concrete [Celebration] instances for a given liturgical year.
///
/// Every registered [LiturgicalCalendar] contributes its
/// [CelebrationDefinition]s.
///
/// When multiple celebrations fall on the same day they are ordered by
/// liturgical precedence (highest rank first). The generator preserves every
/// celebration; later layers decide which one becomes the primary celebration
/// and which become commemorations.
class CelebrationGenerator {
  final List<LiturgicalCalendar> calendars;
  final LiturgicalPrecedence precedence;

  const CelebrationGenerator({
    required this.calendars,
    required this.precedence,
  });

  List<Celebration> generate(int year) {
    final context = CalendarContext(
      year: year,
      settings: CalendarSettings.roman,
    );

    final celebrationsByDate = <DateTime, List<Celebration>>{};

    for (final calendar in calendars) {
      final definitions = calendar.celebrationsForYear(year);

      for (final definition in definitions) {
        final date = _normalize(definition.rule.resolve(context));

        final celebration = Celebration(definition: definition, date: date);

        celebrationsByDate
            .putIfAbsent(date, () => <Celebration>[])
            .add(celebration);
      }
    }

    final result = <Celebration>[];

    final orderedDates = celebrationsByDate.keys.toList()..sort();

    for (final date in orderedDates) {
      final celebrations = celebrationsByDate[date]!;

      celebrations.sort(
        (a, b) => precedence.compare(a.definition, b.definition),
      );

      // For now return only the highest-ranking celebration.
      // Later, LiturgicalDay will store the remaining celebrations
      // as commemorations / optional memorials.
      result.add(celebrations.first);
    }

    return result;
  }

  DateTime _normalize(DateTime date) {
    return DateTime(date.year, date.month, date.day);
  }
}
