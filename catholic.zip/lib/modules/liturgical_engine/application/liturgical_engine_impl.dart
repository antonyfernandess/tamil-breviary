import '../domain/calculations/season/liturgical_season_calculator.dart';
import '../domain/entities/celebration.dart';
import '../domain/entities/liturgical_day.dart';
import '../domain/entities/liturgical_year.dart';
import '../domain/enums/liturgical_color.dart';
import '../domain/enums/liturgical_rank.dart';
import '../domain/enums/liturgical_season.dart';
import '../domain/value_objects/calendar_settings.dart';
import '../domain/value_objects/celebration_key.dart';
import 'celebration_generator.dart';
import 'liturgical_engine.dart';

class LiturgicalEngineImpl implements LiturgicalEngine {
  final CelebrationGenerator generator;
  final Map<int, LiturgicalYear> _yearCache = {};
  final CalendarSettings settings;

  LiturgicalEngineImpl({
    required this.generator,
    this.settings = CalendarSettings.roman,
  });

  @override
  LiturgicalDay getDay(DateTime date) {
    final normalized = DateTime(date.year, date.month, date.day);
    final liturgicalYear = getYear(normalized.year);
    return liturgicalYear.getDay(normalized)!;
  }

  @override
  LiturgicalYear getYear(int year) {
    return _yearCache.putIfAbsent(year, () => _generateYear(year));
  }

  /// Builds every single date of [year] (Jan 1 through Dec 31) in one
  /// pass. Named celebrations take precedence; every other date
  /// falls back to a plain feria/Sunday for its season. This runs
  /// once per year and is cached, so a full month or year view never
  /// has to repeat the season calculation per date.
  LiturgicalYear _generateYear(int year) {
    final liturgicalYear = LiturgicalYear(year: year);

    final celebrationsByDate = <DateTime, Celebration>{};
    for (final celebration in generator.generate(year)) {
      celebrationsByDate[_normalize(celebration.date)] = celebration;
    }

    final startOfYear = DateTime(year, 1, 1);
    final startOfNextYear = DateTime(year + 1, 1, 1);
    final totalDays = startOfNextYear.difference(startOfYear).inDays;

    for (var i = 0; i < totalDays; i++) {
      final date = startOfYear.add(Duration(days: i));

      final day = _buildDay(date, celebrationsByDate[_normalize(date)]);

      liturgicalYear.addDay(day);
    }

    return liturgicalYear;
  }

  LiturgicalDay _buildDay(DateTime date, Celebration? celebration) {
    if (celebration != null) {
      return LiturgicalDay(
        date: date,
        celebration: celebration.definition.key,
        season: LiturgicalSeasonCalculator.resolve(date),
        rank: celebration.definition.rank,
        color: celebration.definition.color,
      );
    }

    final season = LiturgicalSeasonCalculator.resolve(date);

    return LiturgicalDay(
      date: date,
      celebration: CelebrationKey(
        date.weekday == DateTime.sunday
            ? '${season.name}_sunday'
            : '${season.name}_feria',
      ),
      season: season,
      rank: LiturgicalRank.feria,
      color: _defaultColorFor(season),
    );
  }

  LiturgicalColor _defaultColorFor(LiturgicalSeason season) {
    switch (season) {
      case LiturgicalSeason.advent:
      case LiturgicalSeason.lent:
        return LiturgicalColor.violet;
      case LiturgicalSeason.christmas:
      case LiturgicalSeason.easter:
        return LiturgicalColor.white;
      case LiturgicalSeason.sacredTriduum:
        return LiturgicalColor.red;
      case LiturgicalSeason.ordinaryTime:
        return LiturgicalColor.green;
    }
  }

  DateTime _normalize(DateTime date) =>
      DateTime(date.year, date.month, date.day);
}
